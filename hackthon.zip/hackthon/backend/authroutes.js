const express = require("express");
const bcrypt = require("bcryptjs");
const nodemailer = require("nodemailer");
const db = require("./db");

const router = express.Router();
const otpStore = {}; // Store OTPs temporarily

router.post("/send-otp", async (req, res) => {
    const { userid, email } = req.body;

    const sql = "SELECT * FROM users WHERE userid = ? AND email = ?";
    db.query(sql, [userid, email], async (err, results) => {
        if (err) return res.status(500).json({ error: "Database Error" });
        if (results.length === 0) return res.status(404).json({ error: "User Not Found" });

        // Generate OTP
        const otp = Math.floor(100000 + Math.random() * 900000);
        otpStore[userid] = otp;

        // Send OTP via Email
        const transporter = nodemailer.createTransport({
            service: "gmail",
            auth: {
                user: "peertopeerknowledgesharing@gmail.com", // 🔹 Your Gmail
                pass: "reqn vdmy nnrq iare" // 🔹 Your Gmail App Password
            }
        });

        const mailOptions = {
            from: "peertopeerknowledgesharing@gmail.com",
            to: email,
            subject: "Password Reset OTP",
            text: `Your OTP for password reset is: ${otp}`
        };

        transporter.sendMail(mailOptions, (error, info) => {
            if (error) return res.status(500).json({ error: "Email not sent" });
            res.json({ message: "OTP Sent!" });
        });
    });
});

// Reset Password
router.post("/reset-password", async (req, res) => {
    const { userid, otp, newPassword } = req.body;

    if (otpStore[userid] != otp) return res.status(400).json({ error: "Invalid OTP" });

    try {
        const hashedPassword = await bcrypt.hash(newPassword, 10);
        const sql = "UPDATE users SET password = ? WHERE userid = ?";
        db.query(sql, [hashedPassword, userid], (err, result) => {
            if (err) return res.status(500).json({ error: "Database Error" });

            delete otpStore[userid]; // Clear OTP after use
            res.json({ message: "Password Reset Successfully!" });
        });
    } catch (error) {
        res.status(500).json({ error: "Internal Server Error" });
    }
});

router.post("/forgot-userid", async (req, res) => {
    const { email } = req.body;

    // Query to find the user by email
    const sql = "SELECT userid FROM users WHERE email = ?";
    db.query(sql, [email], (err, results) => {
        if (err) {
            console.error("❌ Database Error:", err);
            return res.status(500).json({ error: "Internal Server Error" });
        }
        if (results.length === 0) {
            return res.status(404).json({ error: "❌ No user found with this email!" });
        }

        // User found, send User ID via email
        const userId = results[0].userid;
        
        // Setup email transporter
        const transporter = nodemailer.createTransport({
            service: "gmail",
            auth: {
                user: "peertopeerknowledgesharing@gmail.com", // Replace with your email
                pass: "reqn vdmy nnrq iare" // Replace with your Gmail App password
            }
        });

        const mailOptions = {
            from: "peertopeerknowledgesharing@gmail.com", // Replace with your email
            to: email,
            subject: "User ID Retrieval",
            text: `Your User ID is: ${userId}`
        };

        transporter.sendMail(mailOptions, (error, info) => {
            if (error) {
                console.error("❌ Email Error:", error);
                return res.status(500).json({ error: "❌ Email not sent!" });
            }
            res.json({ message: "✅ Your User ID has been sent to your email!" });
        });
    });
});


router.post("/register", async (req, res) => {
    console.log("Received Data:", req.body); // Debugging

    const { name, email, userid, phone, password, confirmPassword, courses } = req.body;

    if (password !== confirmPassword) {
        return res.status(400).json({ error: "❌ Passwords do not match!" });
    }

    try {
        // Check if email already exists
        const sqlCheck = "SELECT * FROM users WHERE email = ?";
        db.query(sqlCheck, [email], async (err, results) => {
            if (err) {
                console.error("❌ Database Error:", err);
                return res.status(500).json({ error: "Internal Server Error" });
            }

            if (results.length > 0) {
                return res.status(400).json({ error: "❌ Email already exists! Please use a different email." });
            }

            // Proceed with registration if email is unique
            const hashedPassword = await bcrypt.hash(password, 10);
            const courseList = Array.isArray(courses) ? courses.join(", ") : courses;

            const sqlInsert = "INSERT INTO users (name, email, userid, phone, password, course_teach) VALUES (?, ?, ?, ?, ?, ?)";
            db.query(sqlInsert, [name, email, userid, phone, hashedPassword, courseList], (insertErr, result) => {
                if (insertErr) {
                    console.error("❌ Database Error:", insertErr);
                    return res.status(500).json({ error: "Internal Server Error" });
                }
                res.json({ message: "✅ User Registered Successfully!" });
            });
        });
    } catch (error) {
        console.error("❌ Encryption Error:", error);
        res.status(500).json({ error: "Internal Server Error" });
    }
});


// 🔑 User Login
router.post("/login", async (req, res) => {
    const { userid, password } = req.body;

    // 🛑 Check if user exists
    const sql = "SELECT * FROM users WHERE userid = ?";
    db.query(sql, [userid], async (err, results) => {
        if (err) return res.status(500).json({ error: "❌ Database Error!" });
        if (results.length === 0) return res.status(401).json({ error: "❌ User ID Not Found!" });

        const user = results[0];

        // 🛑 Check if password matches
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) return res.status(401).json({ error: "❌ Invalid Password!" });

        res.json({ message: "✅ Login Successful!", user });
    });
});

router.post("/enroll", async (req, res) => {
    const { course_name, user_id, course_creator_id } = req.body;

    if (!course_name || !user_id || !course_creator_id) {
        return res.status(400).json({ success: false, message: "Missing required fields" });
    }

    try {
        const query = `
            UPDATE users 
            SET enrolled_courses = JSON_ARRAY_APPEND(IFNULL(enrolled_courses, '[]'), '$', JSON_OBJECT('course', ?, 'creator_id', ?))
            WHERE id = ?
        `;
        await db.query(query, [course_name, course_creator_id, user_id]);

        res.json({ success: true, message: "Enrolled successfully" });
    } catch (error) {
        console.error("Error enrolling course:", error);
        res.status(500).json({ success: false, message: "Server error" });
    }
});


router.get("/available-courses", async (req, res) => {
    try {
        const query = "SELECT users.name, users.course_teach FROM users WHERE course_teach IS NOT NULL";
        db.query(query, (err, results) => {
            if (err) return res.status(500).json({ error: "Database Error" });

            let courses = [];
            results.forEach(row => {
                if (row.course_teach) {
                    const courseList = row.course_teach.split(",").map(course => course.trim());
                    courseList.forEach(course => {
                        courses.push({ course_name: course, creator_name: row.name }); // 🔹 Name instead of User ID
                    });
                }
            });

            console.log("Courses Data Sent: ", courses); // ✅ Debugging log
            res.json({ success: true, courses });
        });
    } catch (error) {
        res.status(500).json({ success: false, message: "Server error" });
    }
});


// 🔹 Remove Enrolled Course
router.post("/remove-enrolled-course", (req, res) => {
    const { userid, courseName } = req.body;

    if (!userid || !courseName) {
        return res.status(400).json({ error: "User ID and Course Name are required" });
    }

    const sqlGet = "SELECT enrolled_courses FROM users WHERE userid = ?";
    db.query(sqlGet, [userid], (err, results) => {
        if (err) {
            console.error("Database Error:", err);
            return res.status(500).json({ error: "Internal Server Error" });
        }
        if (results.length === 0) {
            return res.status(404).json({ error: "User not found" });
        }

        let enrolledCourses = results[0]?.enrolled_courses ? results[0].enrolled_courses.split(",") : [];
        enrolledCourses = enrolledCourses.filter(course => course.trim() !== courseName.trim());

        const updatedCourses = enrolledCourses.length > 0 ? enrolledCourses.join(",") : null; // Avoid empty strings
        const sqlUpdate = "UPDATE users SET enrolled_courses = ? WHERE userid = ?";
        db.query(sqlUpdate, [updatedCourses, userid], (updateErr) => {
            if (updateErr) {
                console.error("Database Error:", updateErr);
                return res.status(500).json({ error: "Failed to update courses" });
            }
            res.json({ message: "✅ Course removed successfully!" });
        });
    });
});

router.post("/submit-feedback", async (req, res) => {
    const { name, email, message } = req.body;

    if (!name || !email || !message) {
        console.log("❌ Missing fields:", { name, email, message });
        return res.status(400).json({ error: "All fields are required!" });
    }

    console.log("✅ Received Feedback:", { name, email, message });

    const transporter = nodemailer.createTransport({
        service: "gmail",
        auth: {
            user: "peertopeerknowledgesharing@gmail.com",
            pass: "reqn vdmy nnrq iare"
        }
    });

    try {
        console.log("📨 Sending email...");
        await transporter.sendMail({
            from: email,
            to: "peertopeerknowledgesharing@gmail.com",
            subject: `New Feedback from ${name}`,
            text: `Name: ${name}\nEmail: ${email}\nMessage: ${message}`
        });

        console.log("✅ Email sent to admin!");

        await transporter.sendMail({
            from: "peertopeerknowledgesharing@gmail.com",
            to: email,
            subject: "Thank You for Your Feedback!",
            text: `Hi ${name},\n\nThank you for reaching out! We received your message and will get back to you soon.\n\nYour Message:\n${message}\n\nBest Regards,\nYour Team`
        });

        console.log("✅ Auto-reply sent to user!");

        res.json({ message: "Feedback submitted successfully!" });
    } catch (error) {
        console.error("❌ Error Sending Email:", error);
        res.status(500).json({ error: "Error sending email" });
    }
});

router.get("/check-email", (req, res) => {
    const email = req.query.email;
    if (!email) return res.status(400).json({ error: "Email is required" });

    const sql = "SELECT * FROM users WHERE email = ?";
    db.query(sql, [email], (err, results) => {
        if (err) {
            console.error("Database Error:", err);
            return res.status(500).json({ error: "Internal Server Error" });
        }

        if (results.length > 0) {
            return res.json({ exists: true });
        } else {
            return res.json({ exists: false });
        }
    });
});

router.post("/send-message", (req, res) => {
    const { senderId, receiverId, message } = req.body;

    if (!senderId || !receiverId || !message.trim()) {
        return res.status(400).json({ error: "❌ All fields are required" });
    }

    console.log("📩 Received Message Data:", { senderId, receiverId, message });

    const sql = "INSERT INTO messages (sender_id, receiver_id, message) VALUES (?, ?, ?)";
    db.query(sql, [senderId, receiverId, message], (err, result) => {
        if (err) {
            console.error("❌ Database Insert Error:", err);
            return res.status(500).json({ error: "Failed to send message" });
        }
        console.log("✅ Message Inserted Successfully:", result);
        res.json({ message: "✅ Message sent successfully!" });
    });
});


router.post("/send-message", (req, res) => {
    const { senderId, receiverId, message } = req.body;

    if (!senderId || !receiverId || !message.trim()) {
        return res.status(400).json({ error: "❌ All fields are required" });
    }

    console.log("📩 Received Message Data:", { senderId, receiverId, message });

    const sql = "INSERT INTO messages (sender_id, receiver_id, message) VALUES (?, ?, ?)";
    db.query(sql, [senderId, receiverId, message], (err, result) => {
        if (err) {
            console.error("❌ Database Insert Error:", err);
            return res.status(500).json({ error: "Failed to send message" });
        }
        console.log("✅ Message Inserted Successfully:", result);
        res.json({ message: "✅ Message sent successfully!" });
    });
});

// 🔐 Change Password Route
router.post("/change-password", async (req, res) => {
    const { userId, oldPassword, newPassword } = req.body;

    if (!userId || !oldPassword || !newPassword) {
        return res.status(400).json({ error: "❌ Missing required fields" });
    }

    try {
        // 🔍 Fetch the user's current password
        db.query("SELECT password FROM users WHERE userid = ?", [userId], async (err, results) => {
            if (err) {
                console.error("❌ Database Error:", err);
                return res.status(500).json({ error: "Internal Server Error" });
            }

            if (results.length === 0) {
                return res.status(404).json({ error: "❌ User not found" });
            }

            const storedPassword = results[0].password;

            // 🔑 Compare old password with hashed password
            const passwordMatch = await bcrypt.compare(oldPassword, storedPassword);
            if (!passwordMatch) {
                return res.status(401).json({ error: "❌ Old password is incorrect" });
            }

            // 🔒 Hash the new password
            const hashedPassword = await bcrypt.hash(newPassword, 10);

            // ✅ Update Password
            db.query("UPDATE users SET password = ? WHERE userid = ?", [hashedPassword, userId], (updateErr) => {
                if (updateErr) {
                    console.error("❌ Error updating password:", updateErr);
                    return res.status(500).json({ error: "Failed to update password" });
                }
                res.json({ message: "✅ Password updated successfully!" });
            });
        });
    } catch (error) {
        console.error("❌ Error:", error);
        res.status(500).json({ error: "Internal Server Error" });
    }
});

module.exports = router;
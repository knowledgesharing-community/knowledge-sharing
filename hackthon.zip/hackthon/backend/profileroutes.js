const express = require("express");
const router = express.Router();
const db = require("./db");

// 🔹 Fetch User Profile
router.get("/profile/:userid", (req, res) => {
    const { userid } = req.params;
    const query = "SELECT userid, name AS fullname, course_teach AS courses, email, phone FROM users WHERE userid = ?";

    db.query(query, [userid], (err, result) => {
        if (err) return res.status(500).json({ error: "Database Error", details: err });
        if (result.length === 0) return res.status(404).json({ error: "User Not Found" });
        res.json(result[0]);
    });
});

// 🔹 Update User Profile
router.put("/profile/:userid", (req, res) => {
    const { userid } = req.params;
    const { fullname, courses, email, phone } = req.body;
    
    const query = "UPDATE users SET name = ?, course_teach = ?, email = ?, phone = ? WHERE userid = ?";
    db.query(query, [fullname, courses, email, phone, userid], (err, result) => {
        if (err) return res.status(500).json({ error: "Database Update Error", details: err });
        res.json({ message: "✅ Profile updated successfully!" });
    });
});

// Fetch user courses
router.get("/mycourses/:userid", (req, res) => {
    const { userid } = req.params;
    const query = "SELECT course_teach AS courses FROM users WHERE userid = ?";

    db.query(query, [userid], (err, result) => {
        if (err) return res.status(500).json({ error: "Database Error", details: err });
        if (result.length === 0) return res.status(404).json({ error: "User Not Found" });
        res.json(result[0]);
    });
});

// Update courses for a user
router.put("/mycourses/:userid", (req, res) => {
    const { userid } = req.params;
    const { newCourse } = req.body;

    // Fetch existing courses
    db.query("SELECT course_teach FROM users WHERE userid = ?", [userid], (err, result) => {
        if (err) return res.status(500).json({ error: "Database Error", details: err });

        if (result.length === 0) {
            return res.status(404).json({ error: "User Not Found" });
        }

        let existingCourses = result[0].course_teach ? result[0].course_teach.split(",") : [];
        existingCourses.push(newCourse); // Add new course

        const updatedCourses = existingCourses.join(", "); // Convert back to string

        // Update in DB
        db.query("UPDATE users SET course_teach = ? WHERE userid = ?", [updatedCourses, userid], (err, updateResult) => {
            if (err) return res.status(500).json({ error: "Database Update Error", details: err });

            res.json({ message: "✅ Course added successfully!", updatedCourses });
        });
    });
});

router.get("/enrolledcourses/:userid", (req, res) => {
    const { userid } = req.params;
    const query = "SELECT enrolled_courses FROM users WHERE userid = ?";

    db.query(query, [userid], (err, result) => {
        if (err) return res.status(500).json({ error: "Database Error", details: err });
        if (result.length === 0) return res.status(404).json({ error: "User Not Found" });
        res.json({ courses: result[0].enrolled_courses || "" });
    });
});

router.get("/searchcourses", (req, res) => {
    const { query } = req.query;
    if (!query) return res.status(400).json({ error: "Query required" });

    const sql = "SELECT DISTINCT course_teach FROM users WHERE course_teach LIKE ?";
    db.query(sql, [`%${query}%`], (err, result) => {
        if (err) return res.status(500).json({ error: "Database Error", details: err });

        let allCourses = [];
        result.forEach(row => {
            let courses = row.course_teach.split(",").map(course => course.trim());
            allCourses.push(...courses);
        });

        // **Exact match filtering**
        const filteredCourses = allCourses.filter(course => course.toLowerCase().includes(query.toLowerCase()));

        res.json({ courses: [...new Set(filteredCourses)] }); // Remove duplicates
    });
});


router.put("/enrolledcourses/:userid", (req, res) => {
    const { userid } = req.params;
    const { newCourse } = req.body;

    db.query("SELECT enrolled_courses FROM users WHERE userid = ?", [userid], (err, result) => {
        if (err) return res.status(500).json({ error: "Database Error", details: err });

        if (result.length === 0) {
            return res.status(404).json({ error: "User Not Found" });
        }

        let existingCourses = result[0].enrolled_courses ? result[0].enrolled_courses.split(",") : [];
        existingCourses.push(newCourse);

        const updatedCourses = existingCourses.join(", ");

        db.query("UPDATE users SET enrolled_courses = ? WHERE userid = ?", [updatedCourses, userid], (err, updateResult) => {
            if (err) return res.status(500).json({ error: "Database Update Error", details: err });

            res.json({ message: "✅ Course enrolled successfully!", updatedCourses });
        });
    });
});

router.get("/searchcourses", (req, res) => {
    const { query } = req.query;
    if (!query) return res.status(400).json({ error: "Query required" });

    const sql = "SELECT DISTINCT course_teach FROM users WHERE course_teach LIKE ?";
    db.query(sql, [`%${query}%`], (err, result) => {
        if (err) return res.status(500).json({ error: "Database Error", details: err });

        // Convert fetched courses into a single list (not comma-separated)
        let allCourses = [];
        result.forEach(row => {
            let courses = row.course_teach.split(",").map(course => course.trim());
            allCourses.push(...courses);
        });

        // Remove duplicates & send response
        res.json({ courses: [...new Set(allCourses)] });
    });
});



module.exports = router;
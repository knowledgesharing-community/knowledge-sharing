const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const cors = require("cors");
const bodyParser = require("body-parser");
require("dotenv").config();
const db = require("./db");

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
    cors: {
        origin: "*",
        methods: ["GET", "POST"]
    }
});

app.use(cors());
app.use(bodyParser.json());

const authRoutes = require("./authroutes");
const profileRoutes = require("./profileroutes");

app.use("/auth", authRoutes);
app.use("/", profileRoutes);

// ✅ Search for Courses and Show Teaching & Enrolled Courses
app.get("/searchcourses", (req, res) => {
    const query = req.query.query;
    if (!query) return res.status(400).json({ error: "Query is required" });

    const sql = `
        SELECT userid, course_teach, enrolled_courses 
        FROM users 
        WHERE course_teach LIKE ? OR enrolled_courses LIKE ?`;

    db.query(sql, [`%${query}%`, `%${query}%`], (err, results) => {
        if (err) {
            console.error("❌ Database Error:", err);
            return res.status(500).json({ error: "Internal Server Error" });
        }

        let courses = [];
        results.forEach(row => {
            if (row.course_teach) {
                row.course_teach.split(",").forEach(course => {
                    if (course.trim().toLowerCase().includes(query.toLowerCase())) {
                        courses.push({ type: "Teaching", course_name: course.trim(), userid: row.userid });
                    }
                });
            }
            if (row.enrolled_courses) {
                row.enrolled_courses.split(",").forEach(course => {
                    if (course.trim().toLowerCase().includes(query.toLowerCase())) {
                        courses.push({ type: "Enrolled", course_name: course.trim(), userid: row.userid });
                    }
                });
            }
        });

        console.log("✅ Processed Courses:", courses);
        res.json(courses);
    });
});



// ✅ Fetch Available Courses from users table
app.get("/available-courses", (req, res) => {
    const query = `SELECT userid, course_teach FROM users`;

    db.query(query, (err, results) => {
        if (err) {
            console.error("❌ Database Error:", err);
            return res.status(500).json({ error: "Internal Server Error" });
        }

        console.log("📌 Raw Data from DB:", results);  // Debugging  

        let courses = [];
        results.forEach(row => {
            if (row.course_teach) {
                row.course_teach.split(",").forEach(course => {
                    courses.push({ course_name: course.trim(), userid: row.userid });
                });
            }
        });

        console.log("✅ Processed Courses:", courses);  // Debugging  
        res.json(courses);
    });
});



// ✅ Fetch Enrolled Courses with UserID
app.get("/enrolledcourses/:userId", (req, res) => {
    const userId = req.params.userId;

    const query = "SELECT enrolled_courses FROM users WHERE userid = ?";
    
    db.query(query, [userId], (err, rows) => {
        if (err) {
            console.error("❌ Database Error:", err);
            return res.status(500).json({ error: "Database query failed" });
        }

        if (!rows || rows.length === 0 || !rows[0].enrolled_courses) {
            return res.json({ courses: [], user_ids: {} });
        }

        let enrolledCourses = rows[0].enrolled_courses.split(",");

        // 🔹 Fetch `userid` for each enrolled course from `users` table
        const instructorQuery = "SELECT userid, course_teach FROM users WHERE course_teach IS NOT NULL";

        db.query(instructorQuery, (err, instructorRows) => {
            if (err) {
                console.error("❌ Error fetching user IDs:", err);
                return res.status(500).json({ error: "Database query failed" });
            }

            let userMap = {}; // Store { course_name: userid }
            instructorRows.forEach(row => {
                row.course_teach.split(",").forEach(course => {
                    userMap[course.trim()] = row.userid;
                });
            });

            let coursesWithUsers = enrolledCourses.map(course => ({
                course_name: course.trim()
            }));

            res.json({ courses: enrolledCourses.join(","), user_ids: userMap });
        });
    });
});


// ✅ Enroll a User in a Course
app.post("/enroll", (req, res) => {
    const { userId, course, instructorId } = req.body;

    if (!userId || !course || !instructorId) {
        return res.status(400).json({ error: "Missing userId, course, or instructorId" });
    }

    const selectQuery = "SELECT enrolled_courses FROM users WHERE userid = ?";

    db.query(selectQuery, [userId], (err, results) => {
        if (err) return res.status(500).json({ error: "Database Error" });

        let enrolledCourses = results[0]?.enrolled_courses ? results[0].enrolled_courses.split(",") : [];

        const newEntry = `${course}(${instructorId})`;
        if (enrolledCourses.includes(newEntry)) {
            return res.status(400).json({ error: "Already enrolled in this course" });
        }

        enrolledCourses.push(newEntry);
        const updatedCourses = enrolledCourses.join(",");

        const updateQuery = "UPDATE users SET enrolled_courses = ? WHERE userid = ?";
        db.query(updateQuery, [updatedCourses, userId], (updateErr) => {
            if (updateErr) return res.status(500).json({ error: "Enrollment failed" });

            console.log(`✅ User ${userId} enrolled in ${course} from ${instructorId}`);

            // ✅ Store notification for instructor
            const notificationQuery = "INSERT INTO notifications (userid, message, is_read, created_at) VALUES (?, ?, 0, NOW())";

            const notificationMessage = `📢 ${userId} enrolled in your course: ${course}`;

            db.query(notificationQuery, [instructorId, notificationMessage], (notifErr) => {
                if (notifErr) console.error("❌ Notification Error:", notifErr);
            });

            res.json({ message: "Course enrolled successfully!" });
        });
    });
});




app.get("/enrolledcourses/:userId", (req, res) => {
    const userId = req.params.userId;

    const query = "SELECT enrolled_courses FROM users WHERE userid = ?";
    
    db.query(query, [userId], (err, rows) => {
        if (err) return res.status(500).json({ error: "Database query failed" });

        if (!rows || rows.length === 0 || !rows[0].enrolled_courses) {
            return res.json({ courses: [] });
        }

        let enrolledCourses = rows[0].enrolled_courses.split(",").map(course => {
            const match = course.match(/(.+?)\((.+?)\)/);
            return match ? { course_name: match[1], instructor_id: match[2] } : null;
        }).filter(Boolean); // Filter out null values

        res.json({ courses: enrolledCourses });
    });
});



app.post("/remove-course", (req, res) => {
    const { userId, course } = req.body;

    if (!userId || !course) {
        return res.status(400).json({ error: "Missing userId or course name" });
    }

    // Fetch user's enrolled courses
    db.query("SELECT enrolled_courses FROM users WHERE userid = ?", [userId], (err, results) => {
        if (err) {
            console.error("❌ Database Error:", err);
            return res.status(500).json({ error: "Internal server error", details: err.message });
        }

        if (!results || results.length === 0) {
            return res.status(404).json({ error: "User not found" });
        }

        let enrolledCourses = results[0].enrolled_courses || ""; // Handle NULL
        let coursesArray = enrolledCourses.split(",").map(c => c.trim());

        if (!coursesArray.includes(course)) {
            return res.status(400).json({ error: "Course not found in enrolled list" });
        }

        // Remove the course
        coursesArray = coursesArray.filter(c => c !== course);
        const updatedCourses = coursesArray.length ? coursesArray.join(",") : null;

        // Update in database
        db.query("UPDATE users SET enrolled_courses = ? WHERE userid = ?", [updatedCourses, userId], (updateErr) => {
            if (updateErr) {
                console.error("❌ Update Error:", updateErr);
                return res.status(500).json({ error: "Internal server error", details: updateErr.message });
            }
            return res.json({ success: true, message: "✅ Course removed successfully!" });
        });
    });
});



// ✅ Fetch Chat History
app.get("/chat-history/:course", (req, res) => {
    const course = req.params.course;
    const sql = "SELECT sender, message FROM chat_messages WHERE course = ?";
    
    db.query(sql, [course], (err, results) => {
        if (err) return res.status(500).json({ error: "Database Error" });
        res.json({ messages: results });
    });
});

// ✅ Store Online Users
const onlineUsers = {};

// ✅ Start Chat Function
app.post("/startChat", (req, res) => {
    const { userId, instructorId, course } = req.body;
    if (!userId || !instructorId || !course) {
        return res.status(400).json({ error: "Missing userId, instructorId, or course" });
    }

    console.log(`Chat started between ${userId} and ${instructorId} for course ${course}`);
    io.emit("joinChat", { userId, chatWith: instructorId, course }); 
    res.json({ message: "Chat started successfully!" });
});

// ✅ Store Chat Messages in Database
app.post("/send-message", (req, res) => {
    const { senderId, receiverId, message } = req.body;

    if (!senderId || !receiverId || !message) {
        return res.status(400).json({ error: "Missing required fields" });
    }

    const sql = "INSERT INTO chat_messages (sender_id, receiver_id, message) VALUES (?, ?, ?)";
    db.query(sql, [senderId, receiverId, message], (err, result) => {
        if (err) {
            console.error("❌ Database Error:", err);
            return res.status(500).json({ error: "Database error" });
        }

        console.log(`✅ Message stored: ${senderId} → ${receiverId}: ${message}`);

        // ✅ Store notification for the receiver
        const notificationQuery = "INSERT INTO notifications (user_id, message, is_read) VALUES (?, ?, 0)";
        const notificationMessage = `💬 New message from ${senderId}: "${message}"`;

        db.query(notificationQuery, [receiverId, notificationMessage], (notifErr) => {
            if (notifErr) console.error("❌ Notification Error:", notifErr);
        });

        res.json({ success: true, message: "Message sent successfully!" });
    });
});


// ✅ Fetch Chat History
app.get("/chat-history/:senderId/:receiverId", (req, res) => {
    const { senderId, receiverId } = req.params;

    const sql = `
        SELECT sender_id AS sender, message, timestamp 
        FROM chat_messages 
        WHERE (sender_id = ? AND receiver_id = ?) 
        OR (sender_id = ? AND receiver_id = ?) 
        ORDER BY timestamp ASC
    `;

    db.query(sql, [senderId, receiverId, receiverId, senderId], (err, results) => {
        if (err) {
            console.error("❌ Database Error:", err);
            return res.status(500).json({ error: "Database error" });
        }
        res.json({ messages: results });
    });
});


app.get("/chat-history/:sender/:receiver", (req, res) => {
    const { sender, receiver } = req.params;

    const sql = `SELECT sender, message FROM chat_messages 
                 WHERE (sender = ? AND receiver = ?) OR (sender = ? AND receiver = ?) 
                 ORDER BY id ASC`;

    db.query(sql, [sender, receiver, receiver, sender], (err, results) => {
        if (err) {
            console.error("❌ Database Error:", err);
            return res.status(500).json({ error: "Database error" });
        }
        res.json({ messages: results });
    });
});

// ✅ Fetch User Details by UserID (Excluding Phone Number)
// ✅ Fetch User Details (Including Courses Teaching & Enrolled)
app.get("/users/:userid", (req, res) => {
    const userId = req.params.userid;

    const query = `
        SELECT name, email, userid, 
               IFNULL(course_teach, '') AS course_teach, 
               IFNULL(enrolled_courses, '') AS enrolled_courses 
        FROM users 
        WHERE userid = ?
    `;

    db.query(query, [userId], (err, results) => {
        if (err) {
            console.error("❌ Database Error:", err);
            return res.status(500).json({ error: "Internal Server Error" });
        }

        if (results.length === 0) {
            return res.json({ message: "User not found." });
        }

        const userData = results[0];

        res.json({
            name: userData.name,
            email: userData.email,
            userid: userData.userid,
            course_teach: userData.course_teach.split(",").filter(c => c.trim() !== "").join(", ") || "No Courses",
            enrolled_courses: userData.enrolled_courses.split(",").filter(c => c.trim() !== "").join(", ") || "Not Enrolled in Any Courses"
        });
    });
});



// ✅ Fetch Chat Users for Sidebar (Handles Student + Instructor Role)
app.get("/chat-users/:userId", (req, res) => {
    const userId = req.params.userId;

    // 🔹 Get enrolled courses with instructors
    const enrolledQuery = "SELECT enrolled_courses FROM users WHERE userid = ?";
    db.query(enrolledQuery, [userId], (err, enrolledResult) => {
        if (err) return res.status(500).json({ error: "Database Error" });

        let enrolledInstructors = new Set();
        if (enrolledResult.length && enrolledResult[0].enrolled_courses) {
            enrolledResult[0].enrolled_courses.split(",").forEach(course => {
                let match = course.match(/(.+?)\((.+?)\)/); // Extract "Python(yaswanth123)"
                if (match) enrolledInstructors.add(match[2]); // Get instructor_id
            });
        }

        // 🔹 Get students who enrolled in this user's courses
        const teachQuery = "SELECT userid FROM users WHERE enrolled_courses LIKE ?";
        db.query(teachQuery, [`%(${userId})%`], (err, studentResults) => {
            if (err) return res.status(500).json({ error: "Database Error" });

            let students = studentResults.map(row => row.userid);

            // ✅ Combine students & instructors
            let chatUsers = [...new Set([...students, ...enrolledInstructors])];

            chatUsers = chatUsers.filter(user => user !== userId); // 🔥 Remove self
            res.json({ users: chatUsers });
        });
    });
});

// ✅ Store Chat Messages in Database (Improved real-time messaging)
app.post("/send-message", (req, res) => {
    const { senderId, receiverId, message } = req.body;
    if (!senderId || !receiverId || !message) {
        return res.status(400).json({ error: "Missing required fields" });
    }

    const sql = "INSERT INTO chat_messages (sender_id, receiver_id, message) VALUES (?, ?, ?)";
    db.query(sql, [senderId, receiverId, message], (err, result) => {
        if (err) {
            console.error("❌ Database Error:", err);
            return res.status(500).json({ error: "Database error" });
        }

        console.log(`✅ Message stored: ${senderId} → ${receiverId}: ${message}`);

        // Send message in real-time to the receiver
        if (onlineUsers[receiverId]) {
            io.to(onlineUsers[receiverId]).emit("chatMessage", { senderId, message });
        }

        res.json({ success: true, message: "Message sent successfully!" });
    });
});

io.on("connection", (socket) => {
    console.log(`User Connected: ${socket.id}`);

    socket.on("joinChat", ({ userId }) => {
        console.log(`${userId} joined chat`);
        socket.join(userId); // ✅ User joins their own room
    });

    socket.on("chatMessage", ({ senderId, receiverId, message }) => {
        console.log(`📩 Message from ${senderId} to ${receiverId}: ${message}`);

        const sql = "INSERT INTO chat_messages (sender_id, receiver_id, message) VALUES (?, ?, ?)";
        db.query(sql, [senderId, receiverId, message], (err) => {
            if (err) {
                console.error("❌ Database Error:", err);
                return;
            }

            // ✅ Send message in real-time only to sender & receiver
            io.to(senderId).emit("chatMessage", { senderId, message });
            io.to(receiverId).emit("chatMessage", { senderId, message });
        });
    });
});

// ✅ Submit a review
const nodemailer = require("nodemailer");

const transporter = nodemailer.createTransport({
    service: "gmail",
    auth: {
        user: "peertopeerknowledgesharing@gmail.com", // Your email
        pass: "reqn vdmy nnrq iare" // Your Gmail App Password
    }
});

app.post("/submit-review", async (req, res) => {
    const { userid, rating, review } = req.body;

    if (!userid || !rating || !review) {
        return res.status(400).json({ error: "All fields are required" });
    }

    console.log("✅ Review Data Received:", { userid, rating, review });

    const userQuery = "SELECT email FROM users WHERE userid = ?";
    
    db.query(userQuery, [userid], (err, results) => {
        if (err) {
            console.error("❌ Database Error:", err);
            return res.status(500).json({ error: "Database error" });
        }
        if (results.length === 0) {
            return res.status(400).json({ error: "User not found" });
        }

        const userEmail = results[0].email;

        // ✅ Insert review into the database
        const insertQuery = "INSERT INTO reviews (userid, rating, review_text) VALUES (?, ?, ?)";
        db.query(insertQuery, [userid, rating, review], (err) => {
            if (err) {
                console.error("❌ Error inserting review:", err);
                return res.status(500).json({ error: "Failed to submit review" });
            }

            console.log("✅ Review stored successfully!");

            // ✅ Send email to Admin
            const adminMailOptions = {
                from: "peertopeerknowledgesharing@gmail.com",
                to: "peertopeerknowledgesharing@gmail.com",
                subject: "New User Review Submitted",
                text: `User ${userid} has submitted a review: \n\nRating: ${rating}\nReview: ${review}`
            };

            transporter.sendMail(adminMailOptions, (error, info) => {
                if (error) {
                    console.error("❌ Error sending email to admin:", error);
                } else {
                    console.log("✅ Admin notified via email:", info.response);
                }
            });

            // ✅ Send "Thank you" email to User
            const userMailOptions = {
                from: "peertopeerknowledgesharing@gmail.com",
                to: userEmail,
                subject: "Thank You for Your Review!",
                text: `Hi ${userid},\n\nThank you for your review! We appreciate your feedback and will continue improving.\n\nYour Review:\n"${review}"\n\nBest Regards,\nYour Team`
            };

            transporter.sendMail(userMailOptions, (error, info) => {
                if (error) {
                    console.error("❌ Error sending email to user:", error);
                } else {
                    console.log("✅ User notified via email:", info.response);
                }
            });

            res.json({ success: true, message: "Review submitted successfully!" });
        });
    });
});


// ✅ Check if user exists in the database
app.post("/check-user", (req, res) => {
    const { userid } = req.body; // ✅ Extract userid from request body

    if (!userid) {
        return res.status(400).json({ error: "User ID is required" });
    }

    const userQuery = "SELECT userid FROM users WHERE userid = ?";
    db.query(userQuery, [userid], (err, results) => {
        if (err) {
            console.error("❌ Database Error:", err);
            return res.status(500).json({ error: "Database error" });
        }
        if (results.length === 0) {
            return res.status(400).json({ error: "User not found" });
        }

        console.log("✅ User found:", results[0]);
        res.json({ success: true, user: results[0] });
    });
});


// ✅ Fetch all reviews
app.get("/get-reviews", (req, res) => {
    let sortOption = req.query.sort || "newest";
    let orderBy = "timestamp DESC"; 

    if (sortOption === "oldest") orderBy = "timestamp ASC";
    if (sortOption === "highest") orderBy = "rating DESC";
    if (sortOption === "lowest") orderBy = "rating ASC";

    const sql = `SELECT id, userid, rating, review_text, timestamp FROM reviews ORDER BY ${orderBy}`;
    db.query(sql, (err, results) => {
        if (err) return res.status(500).json({ error: "Database error" });
        res.json(results);
    });
});


// ✅ Edit Review API
app.post("/edit-review", (req, res) => {
    const { reviewId, newText } = req.body;
    if (!reviewId || !newText) {
        return res.status(400).json({ error: "Missing review ID or new text" });
    }

    const sql = "UPDATE reviews SET review_text = ? WHERE id = ?";
    db.query(sql, [newText, reviewId], (err, result) => {
        if (err) {
            console.error("❌ Database Error:", err);
            return res.status(500).json({ error: "Failed to update review" });
        }
        res.json({ success: true, message: "Review updated successfully!" });
    });
});

// ✅ Delete Review API
app.post("/delete-review", (req, res) => {
    const { reviewId } = req.body;
    if (!reviewId) {
        return res.status(400).json({ error: "Missing review ID" });
    }

    const sql = "DELETE FROM reviews WHERE id = ?";
    db.query(sql, [reviewId], (err, result) => {
        if (err) {
            console.error("❌ Database Error:", err);
            return res.status(500).json({ error: "Failed to delete review" });
        }
        res.json({ success: true, message: "Review deleted successfully!" });
    });
});



// ✅ Report Review API
app.post("/report-review", (req, res) => {
    const { reviewId, userId } = req.body;

    if (!reviewId || !userId) {
        return res.status(400).json({ error: "Missing reviewId or userId" });
    }

    const sql = "INSERT INTO reported_reviews (review_id, reported_by) VALUES (?, ?)";
    db.query(sql, [reviewId, userId], (err, result) => {
        if (err) {
            console.error("❌ Database Error:", err);
            return res.status(500).json({ error: "Failed to report review" });
        }
        res.json({ success: true, message: "Review reported successfully!" });
    });
});



app.get("/get-userid", (req, res) => {
const sessionUser = req.headers.userid; // 🔹 Get User ID from session or request header

if (!sessionUser) {
    return res.status(400).json({ error: "User not logged in" });
}

const query = "SELECT userid FROM users WHERE userid = ?";
db.query(query, [sessionUser], (err, results) => {
    if (err) {
        console.error("❌ Database Error:", err);
        return res.status(500).json({ error: "Database error" });
    }
    if (results.length === 0) {
        return res.status(400).json({ error: "User not found" });
    }

    res.json({ userid: results[0].userid });
});
});

app.get("/notifications/:userId", (req, res) => {
    const userId = req.params.userId;

    const query = "SELECT id, message, is_read FROM notifications WHERE userid = ? ORDER BY created_at DESC";
    
    db.query(query, [userId], (err, results) => {
        if (err) {
            console.error("❌ Database Error:", err);
            return res.status(500).json({ error: "Database Error" });
        }
        res.json({ notifications: results });
    });
});

// ✅ Store a new notification
app.post("/add-notification", (req, res) => {
    const { userId, message } = req.body;

    if (!userId || !message) {
        return res.status(400).json({ error: "Missing userId or message" });
    }

    const sql = "INSERT INTO notifications (user_id, message, is_read) VALUES (?, ?, 0)";
    db.query(sql, [userId, message], (err, result) => {
        if (err) {
            console.error("❌ Database Error:", err);
            return res.status(500).json({ error: "Failed to store notification" });
        }
        console.log(`✅ Notification stored for ${userId}: ${message}`);
        res.json({ success: true, message: "Notification added!" });
    });
});

// ✅ Fetch notifications for a user
app.get("/notifications/:userId", (req, res) => {
    const userId = req.params.userId;

    const sql = "SELECT id, message, is_read, created_at FROM notifications WHERE userid = ? ORDER BY created_at DESC";

    db.query(sql, [userId], (err, results) => {
        if (err) {
            console.error("❌ Database Error:", err);
            return res.status(500).json({ error: "Failed to fetch notifications" });
        }
        res.json({ notifications: results });
    });
});

// ✅ Mark a notification as read
app.post("/mark-notification-read", (req, res) => {
    const { notificationId } = req.body;

    if (!notificationId) {
        return res.status(400).json({ error: "❌ Missing notificationId" });
    }

    const sql = "UPDATE notifications SET is_read = 1 WHERE id = ?";
    db.query(sql, [notificationId], (err, result) => {
        if (err) {
            console.error("❌ Database Error:", err);
            return res.status(500).json({ error: "Failed to update notification" });
        }

        if (result.affectedRows === 0) {
            return res.status(404).json({ error: "❌ Notification not found" });
        }

        res.json({ success: true, message: "✅ Notification marked as read!" });
    });
});

// ✅ Fetch Unread Notifications Count
app.get("/unread-notifications/:userId", (req, res) => {
    const userId = req.params.userId;

    const sql = "SELECT COUNT(*) AS unreadCount FROM notifications WHERE userid = ? AND is_read = 0";
    db.query(sql, [userId], (err, result) => {
        if (err) {
            console.error("❌ Database Error:", err);
            return res.status(500).json({ error: "Failed to fetch unread notifications count" });
        }
        res.json({ unreadCount: result[0].unreadCount });
    });
});

// ✅ Mark All Notifications as Read
app.post("/mark-all-read", (req, res) => {
    const { userId } = req.body;

    if (!userId) {
        return res.status(400).json({ error: "Missing userId" });
    }

    const sql = "UPDATE notifications SET is_read = 1 WHERE userid = ?";
    db.query(sql, [userId], (err, result) => {
        if (err) {
            console.error("❌ Database Error:", err);
            return res.status(500).json({ error: "Failed to mark notifications as read" });
        }
        res.json({ success: true, message: "All notifications marked as read!" });
    });
});



// ✅ Delete a Single Notification
app.post("/delete-notification", (req, res) => {
    const { notificationId } = req.body;

    if (!notificationId) {
        return res.status(400).json({ error: "Missing notificationId" });
    }

    const sql = "DELETE FROM notifications WHERE id = ?";
    db.query(sql, [notificationId], (err, result) => {
        if (err) {
            console.error("❌ Database Error:", err);
            return res.status(500).json({ error: "Failed to delete notification" });
        }
        res.json({ success: true, message: "Notification deleted successfully!" });
    });
});

// ✅ Delete All Notifications for a User
app.post("/clear-notifications", (req, res) => {
    const { userId } = req.body;

    if (!userId) {
        return res.status(400).json({ error: "Missing userId" });
    }

    const sql = "DELETE FROM notifications WHERE userid = ?";
    db.query(sql, [userId], (err, result) => {
        if (err) {
            console.error("❌ Database Error:", err);
            return res.status(500).json({ error: "Failed to delete notifications" });
        }
        res.json({ success: true, message: "All notifications cleared!" });
    });
});



const port = process.env.PORT || 5000;
server.listen(port, () => {
    console.log(`🚀 Server running on http://localhost:${port}`);
});
